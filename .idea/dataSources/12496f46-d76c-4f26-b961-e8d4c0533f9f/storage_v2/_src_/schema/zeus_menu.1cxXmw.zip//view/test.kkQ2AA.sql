create definer = root@`%` view test as
select `zeus_menu`.`saber_audit_log`.`id`          AS `id`,
       `zeus_menu`.`saber_audit_log`.`uid`         AS `uid`,
       `zeus_menu`.`saber_audit_log`.`order_id`    AS `order_id`,
       `zeus_menu`.`saber_audit_log`.`from_status` AS `from_status`,
       `zeus_menu`.`saber_audit_log`.`to_status`   AS `to_status`,
       `zeus_menu`.`saber_audit_log`.`reason`      AS `reason`,
       `zeus_menu`.`saber_audit_log`.`created_at`  AS `created_at`,
       `zeus_menu`.`saber_audit_log`.`updated_at`  AS `updated_at`
from `zeus_menu`.`saber_audit_log`
limit 10;

-- comment on column test.uid not supported: 审核人: auth_admin表id

-- comment on column test.order_id not supported: 审核的订单: saber_order表id

-- comment on column test.from_status not supported: 原始状态值

-- comment on column test.to_status not supported: 变更后的状态值

-- comment on column test.reason not supported: 可能填写的原因

